﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Threading;
using System.Collections.Concurrent;
using System.Threading.Tasks;
using log4net;

namespace TSAPILIB2
{
    public enum StatusConection
    {
        Close,
        Open
    }
    public class Event : IDisposable
    {
        private uint _acsHandle;
        public uint AcsHandle
        {
            get
            {
                lock (this)
                {
                    return _acsHandle;
                }
            }
            set
            {
                lock (this)
                {
                    _acsHandle = value;
                }
            }
        }
        private int _invokeId;
        protected Object InvokeIDlock = new object();

        public uint InvokeId
        {
            get
            {
                lock (InvokeIDlock)
                {
                    if (Blocked) { Thread.Sleep(100); Log.DebugFormat("Blocked {0} to 100 ms", LinkName); }
                    var ret = (uint)Interlocked.Increment(ref _invokeId);
                    if (ret > 32000) _invokeId = 0;
                    return ret;
                }
            }

        }

        protected const Int32 Timeout = 5000;

        public static readonly ILog Log = LogManager.GetLogger(typeof(Event));

        public StatusConection StatusConnection = StatusConection.Close;

        protected event DelegateConnected OnConnnectedEvent;

        public delegate void DelegateConnected(object sender, EventArgs e);

        protected event DelegateClosed OnClosedEvent;

        public delegate void DelegateClosed(object sender, EventArgs e);

        protected event DelegateUniversalFailure OnUniversalFailureEvent;

        protected delegate void DelegateUniversalFailure(object sender, UniversalFailureEventArg e);

        protected event DelegateUniversalFailureSys OnUniversalFailureSysEvent;

        public delegate void DelegateUniversalFailureSys(object sender, UniversalFailureSys e);


        protected readonly CbTask<uint> CbTaskNew;
        protected readonly CbTask<int> CbTaskForToPartNew = new CbTask<int>();
        protected readonly ConcurrentDictionary<object, object> ReportArray = new ConcurrentDictionary<object, object>();


        protected ConcurrentDictionary<int, MonitorEventCollection> Monitors = new ConcurrentDictionary<int, MonitorEventCollection>();
        protected ConcurrentDictionary<String, MonitorEventAgentCollection> Agents = new ConcurrentDictionary<string, MonitorEventAgentCollection>();

        private readonly CancellationTokenSource _closed = new CancellationTokenSource();

        protected String Server;
        protected String Login;
        protected String Password;
        protected String AppName;
        public String LinkName
        {
            get
            {
                return AppName;
            }
        }
        protected String ApiVersion;
        protected String PrivateVersion;
        protected AcsEventCallBack CbEvent;

        public ushort SendQSize = 200;
        public ushort SendExtraBufs = 0;
        public ushort RecvQSize = 400;
        public ushort RecvExtraBufs = 0;

        protected Boolean Blocked;
        protected Action MainLoop;
        protected IAsyncResult MainLoopResult;
        protected bool Disposed;

        public Event()
        {
            CbTaskNew = new CbTask<uint>(SendQSize);
            Log.DebugFormat("{0} : Constructor", LinkName);
            MainLoop = EventLoopPull;

        }

        public Event(String server, String login, String password, String appName, String apiVersion, String privateVersion)
            : this()
        {
            Server = server;
            Login = login;
            Password = password;
            AppName = appName;
            ApiVersion = apiVersion;
            PrivateVersion = privateVersion;

        }

        ~Event()
        {

            Dispose(false);
        }



        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }


        private const int SizeBf = 10000;

        readonly IntPtr _ptrCsta = Marshal.AllocHGlobal(SizeBf);
        readonly IntPtr _ptrPd = Marshal.AllocHGlobal(Marshal.SizeOf(typeof(PrivateData_t)));
        readonly IntPtr _ptrAtt = Marshal.AllocHGlobal(SizeBf);

        readonly byte[] _bufferPd = new byte[Marshal.SizeOf(typeof(PrivateData_t))];
        readonly byte[] _bufferCsta = new byte[SizeBf];
        readonly byte[] _bufferAtt = new byte[SizeBf];
        private NativeMethods.ACSEventCallBack _callBackAnkor;


        protected int GetEvent(out CSTAEvent_t csta, out ATTEvent_t att)
        {
            ushort coutnEvent = 0;
            csta = new CSTAEvent_t();
            att = new ATTEvent_t();

            if (AcsHandle == 0) return coutnEvent;
            try
            {
                var pd = new PrivateData_t { length = SizeBf };
                var handlePd = GCHandle.Alloc(_bufferPd, GCHandleType.Pinned);
                var handleCsta = GCHandle.Alloc(_bufferCsta, GCHandleType.Pinned);
                var handleAtt = GCHandle.Alloc(_bufferAtt, GCHandleType.Pinned);
                var handlecoutn = GCHandle.Alloc(coutnEvent, GCHandleType.Pinned);
                var handlepdLength = GCHandle.Alloc(pd.length, GCHandleType.Pinned);
                try
                {
                    Marshal.StructureToPtr(pd, handlePd.AddrOfPinnedObject(), true);
                    var ret = NativeMethods.acsGetEventPoll(AcsHandle, handleCsta.AddrOfPinnedObject(), ref pd.length,
                        handlePd.AddrOfPinnedObject(), out coutnEvent);
                    if (ret == ACSFunctionRet_t.ACSPOSITIVE_ACK)
                    {
                        csta = new CSTAEvent_t(handleCsta.AddrOfPinnedObject());
                        if (csta.eventHeader.eventClass >= EventClass_t.CSTAREQUEST)
                        {

                            NativeMethods.attPrivateData(handlePd.AddrOfPinnedObject(), handleAtt.AddrOfPinnedObject());
                            att = new ATTEvent_t(handleAtt.AddrOfPinnedObject());
                        }
                    }
                    else
                    {
                        if (ret != ACSFunctionRet_t.ACSERR_NOMESSAGE && ret != ACSFunctionRet_t.ACSERR_BADHDL)
                        {
                            Log.Error(new Exeption("acsGetEventPoll", ret));
                        }
                    }
                }
                catch (Exception ex)
                {
                    Log.Error("Marshal:" + CbTaskNew.CurrentCommand(), ex);
                }
                finally
                {
                    if (handlePd.IsAllocated) handlePd.Free();
                    if (handleCsta.IsAllocated) handleCsta.Free();
                    if (handleAtt.IsAllocated) handleAtt.Free();
                    if (handlecoutn.IsAllocated) handlecoutn.Free();
                    if (handlepdLength.IsAllocated) handlepdLength.Free();


                }
            }
            catch (Exeption ex)
            {
                Log.Error("Init:" + CbTaskNew.CurrentCommand(), ex);
            }
            return coutnEvent;

        }
        protected void EventLoopPull()
        {
            do
            {
                GetEvenetPull();
                Thread.Sleep(100);
            } while (!_closed.IsCancellationRequested);

        }
        protected int GetEvenetPull()
        {
            if (AcsHandle == 0) return 0;
            CSTAEvent_t csta;
            ATTEvent_t att;
            var coutnEvent = GetEvent(out csta, out att);
            if (coutnEvent <= -1) return coutnEvent;
            switch (csta.eventHeader.eventClass)
            {
                case EventClass_t.ACSCONFIRMATION:
                    Acsconfirmation(csta.acsConfirmation, csta.eventHeader.eventTypeACS);
                    break;
                case EventClass_t.ACSUNSOLICITED:
                    Acsunsolicited(csta.acsUnsolicited, csta.eventHeader.eventTypeACS);
                    break;
                case EventClass_t.CSTACONFIRMATION:
                    Cstaconfirmation(csta.cstaConfirmation, att, csta.eventHeader.eventTypeCSTA);
                    break;
                case EventClass_t.CSTAEVENTREPORT:
                    Cstaeventreport(csta.cstaEventReport, att, csta.eventHeader.eventTypeCSTA);
                    break;
                case EventClass_t.CSTAREQUEST:
                    Cstarequest(csta.cstaRequest, att, csta.eventHeader.eventTypeCSTA);
                    break;
                case EventClass_t.CSTAUNSOLICITED:
                    Cstaunsolicited(csta.cstaUnsolicited, att, csta.eventHeader.eventTypeCSTA);
                    break;
            }
            return coutnEvent;
        }

        protected void EventCallBack(int lParam)
        {
            GetEvenetPull();
        }


        protected Task<TRet> CreateTask<TRet>(Func<uint, PrivateData_t, ACSFunctionRet_t> functFunc, String commandDescription = "")
        {
            var invokeId = InvokeId;
            var pd = new PrivateData_t();
            var t = CbTaskNew.Add(invokeId, command: commandDescription);
            var ret = functFunc(invokeId, pd);
            if (ret != ACSFunctionRet_t.ACSPOSITIVE_ACK && StatusConnection == StatusConection.Open)
            {
                CbTaskNew.Set(invokeId, default(TRet));
                switch (ret)
                {
                    case ACSFunctionRet_t.ACSERR_APIVERDENIED:
                    case ACSFunctionRet_t.ACSERR_UNKNOWN: break;
                    case ACSFunctionRet_t.ACSERR_NOBUFFERS:
                    case ACSFunctionRet_t.ACSERR_QUEUE_FULL: Blocked = true; break;
                    default:
                        AbortStream();
                        AlertClose();
                        break;
                }
                throw new Exeption(ret);
            }
            Blocked = false;
            t.ContinueWith(task =>
            {
                var ex = task.Exception;
                if (ex == null) return;
                foreach (var exc in ex.Flatten().InnerExceptions)
                {
                    Log.Error(commandDescription, exc);
                }
            },TaskContinuationOptions.OnlyOnFaulted);
            return t.ContinueWith(task => (TRet) task.Result);
        }

        public void InitLoop()
        {
            Task.Factory.StartNew(MainLoop, _closed.Token, TaskCreationOptions.LongRunning, TaskScheduler.Current)
                .ContinueWith(task => InitLoop(), TaskContinuationOptions.OnlyOnFaulted);
        }

        public void OpenStream()
        {
            Log.DebugFormat("{0} : Open stream ", LinkName);
            _acsHandle = 0;
            _invokeId = 0;
            if (MainLoopResult != null)
            {
                Log.DebugFormat("{0} : Wait last main_loop_result", LinkName);
                MainLoopResult.AsyncWaitHandle.WaitOne(10000);
                MainLoopResult = null;
            }
            _callBackAnkor = EventCallBack;

            /*NativeMethods.acsEnumServerNames(StreamType_t.stCsta, (name, param) =>
            {

            }, 0);*/

            CreateTask<object>((u, t) =>
            {
                var pd = new PrivateData_t { vendor = "VERSION" };
                pd.Set(PrivateVersion);
                var ret = NativeMethods.acsOpenStream(
                    out _acsHandle,
                    InvokeIDType_t.APP_GEN_ID,
                    u,
                    StreamType_t.stCsta,
                    Server,
                    Login,
                    Password,
                    AppName,
                    0,
                    ApiVersion,
                    SendQSize,
                    SendExtraBufs,
                    RecvQSize,
                    RecvExtraBufs,
                    ref pd
                    );

                //InitLoop();
                NativeMethods.acsSetESR(_acsHandle, _callBackAnkor, 0, true);

                return ret;

            }).Wait();






            foreach (var monitorEventCollection in Monitors)
            {
                monitorEventCollection.Value.Dispose();
            }
            Monitors.Clear();
        }


        public void CloseStream()
        {
            Log.DebugFormat("{0} : Close stream ", LinkName);
            StatusConnection = StatusConection.Close;
            if (_acsHandle != 0)
            {
                CreateTask<object>((key, pd) => NativeMethods.acsCloseStream(AcsHandle, key, ref pd));
            }
        }

        public void AbortStream()
        {
            Log.DebugFormat("{0} : Abort stream ", LinkName);
            StatusConnection = StatusConection.Close;
            if (_acsHandle != 0)
            {
                var pd = new PrivateData_t();
                var ret = NativeMethods.acsAbortStream(AcsHandle, ref pd);
                if (ret != ACSFunctionRet_t.ACSPOSITIVE_ACK)
                {
                    throw new Exeption("AbortStream", ret);
                }
            }
            AlertClose();
        }


        protected void AnalizeFailurs(ACSUniversalFailure_t error)
        {
            switch (error)
            {
                case ACSUniversalFailure_t.tserverStreamFailed:
                case ACSUniversalFailure_t.tserverNoThread:
                case ACSUniversalFailure_t.tserverDeadDriver:
                case ACSUniversalFailure_t.tserverBadStreamType:
                case ACSUniversalFailure_t.tserverNoNdsOamPermission:
                case ACSUniversalFailure_t.tserverOpenSdbLogFailed:
                case ACSUniversalFailure_t.tserverInvalidLogSize:
                case ACSUniversalFailure_t.tserverWriteSdbLogFailed:
                case ACSUniversalFailure_t.tserverNtFailure:
                case ACSUniversalFailure_t.tserverRegistrationFailed:
                case ACSUniversalFailure_t.tserverBadPwEncryption:
                case ACSUniversalFailure_t.tserverNoVersion:
                case ACSUniversalFailure_t.tserverBadPdu:
                case ACSUniversalFailure_t.tserverBadConnection:
                case ACSUniversalFailure_t.tserverDecodeFailed:
                case ACSUniversalFailure_t.tserverEncodeFailed:
                case ACSUniversalFailure_t.tserverNoMemory:
                case ACSUniversalFailure_t.tserverSpxFailed:
                case ACSUniversalFailure_t.tserverReceiveFromDriver:
                case ACSUniversalFailure_t.tserverSendToDriver:
                case ACSUniversalFailure_t.tserverFreeBufferFailed:
                case ACSUniversalFailure_t.tserverBadServerid:
                case ACSUniversalFailure_t.tserverRequiredModulesNotLoaded:
                case ACSUniversalFailure_t.tserverLoadLibFailed:
                case ACSUniversalFailure_t.tserverInvalidDriver:
                case ACSUniversalFailure_t.tserverDriverLoaded:
                case ACSUniversalFailure_t.tserverBadDriverProtocol:
                    Log.ErrorFormat("{0} : Error ACSUniversalFailure_t : {1} ", LinkName, error);
                    AbortStream();
                    break;

            }
        }

        protected void AlertClose()
        {
            StatusConnection = StatusConection.Close;
            _acsHandle = 0;
            _invokeId = 0;
            if (OnClosedEvent != null) OnClosedEvent(this, null);
        }

        protected void Acsconfirmation(ACSConfirmationEvent data, eventTypeACS eventType)
        {
            switch (eventType)
            {
                case eventTypeACS.ACS_ABORT_STREAM:
                    AlertClose();
                    break;

                case eventTypeACS.ACS_CLOSE_STREAM_CONF:
                    AlertClose();
                    break;

                case eventTypeACS.ACS_OPEN_STREAM_CONF:
                    if (OnConnnectedEvent != null) OnConnnectedEvent(this, null);
                    CbTaskNew.Set(data.invokeID, new NullTsapiReturn());
                    StatusConnection = StatusConection.Open;
                    break;

                case eventTypeACS.ACS_UNIVERSAL_FAILURE_CONF:
                    if (OnUniversalFailureEvent != null)
                        OnUniversalFailureSysEvent(this,
                            new UniversalFailureSys { Error = data.failureEvent.error, EventType = eventType });
                    CbTaskNew.Clear();
                    AnalizeFailurs(data.failureEvent.error);
                    break;

                default:
                    Log.Error(String.Format("{0} : Error ACSCONFIRMATION  ", LinkName), new ProgrammingExeption(String.Format("Не обработан event '{0}' в ACSCONFIRMATION", eventType.ToString())));
                    throw new ProgrammingExeption(String.Format("Не обработан event '{0}' в ACSCONFIRMATION", eventType.ToString()));
            }
        }


        protected void Acsunsolicited(AcsUnsolicitedEvent data, eventTypeACS eventType)
        {
            AnalizeFailurs(data.failureEvent.error);

            if (OnUniversalFailureEvent != null) OnUniversalFailureSysEvent(this, new UniversalFailureSys { Error = data.failureEvent.error, EventType = eventType });
        }



        protected void Cstaconfirmation(CstaConfirmationEvent data, ATTEvent_t attPd, eventTypeCSTA eventType)
        {
            if (eventType == eventTypeCSTA.CSTA_UNIVERSAL_FAILURE_CONF)
            {
                CbTaskNew.SetError(data.invokeID, data.universalFailure.error);
                return;
            }
            object ret;

            switch (eventType)
            {
                case eventTypeCSTA.CSTA_QUERY_DEVICE_INFO_CONF:
                    ret = new QueryDeviceInfoReturn(data, attPd);
                    break;
                case eventTypeCSTA.CSTA_MAKE_CALL_CONF:
                    ret = new MakeCallEventReturn(data, attPd);
                    break;
                case eventTypeCSTA.CSTA_CONSULTATION_CALL_CONF:
                    ret = new ConsultationCallEventReturn(data, attPd);
                    break;
                case eventTypeCSTA.CSTA_MAKE_PREDICTIVE_CALL_CONF:
                    ret = new MakePredictiveCallEventReturn(data, attPd);
                    break;
                case eventTypeCSTA.CSTA_TRANSFER_CALL_CONF:
                    ret = new TransferCallEventReturn(data, attPd);
                    break;
                case eventTypeCSTA.CSTA_QUERY_AGENT_STATE_CONF:
                    ret = new QueryAgentStateEventReturn(data, attPd);
                    break;
                case eventTypeCSTA.CSTA_QUERY_LAST_NUMBER_CONF:
                    ret = new QueryLastNumberEventReturn(data);
                    break;
                case eventTypeCSTA.CSTA_MONITOR_CONF:
                    ret = new SetupMonitorEventReturn(data, attPd);
                    break;
                case eventTypeCSTA.CSTA_CHANGE_MONITOR_FILTER_CONF:
                    ret = new ChangeMonitorFilterEventReturn(data);
                    break;
                case eventTypeCSTA.CSTA_SNAPSHOT_DEVICE_CONF:
                    ret = new SnapshotDeviceEventReturn(data, attPd);
                    break;
                case eventTypeCSTA.CSTA_SNAPSHOT_CALL_CONF:
                    ret = new SnapshotCallEventReturn(data, attPd);
                    break;
                case eventTypeCSTA.CSTA_QUERY_CALL_MONITOR_CONF:
                    ret = new QueryCallMonitorEventReturn(data);
                    break;
                case eventTypeCSTA.CSTA_GET_DEVICE_LIST_CONF:
                    ret = new GetDeviceListEventReturn(data);
                    break;
                case eventTypeCSTA.CSTA_GETAPI_CAPS_CONF:
                    ret = new ApiCapsEventReturn(data, attPd);
                    break;
                case eventTypeCSTA.CSTA_ESCAPE_SVC_CONF:
                    switch (attPd.eventType)
                    {
                        case TypeATTEvent.ATTQueryUcidConfEvent_t_PDU:
                            ret = new QueryUcidEventReturn(attPd);
                            break;
                        case TypeATTEvent.ATTQueryAcdSplitConfEvent_t_PDU:
                            ret = new QueryAcdSplitEventReturn(attPd);
                            break;
                        case TypeATTEvent.ATTQueryAgentLoginConfEvent_t_PDU:
                            ret = new QueryAgentLoginEventReturn(attPd);
                            var task = CbTaskNew.GeTask(data.invokeID);
                            if (task != null)
                            {
                                CbTaskForToPartNew.Add(((QueryAgentLoginEventReturn)ret).Att.privEventCrossRefID, task);
                            }
                            break;
                        default:
                            ret = new NullTsapiReturn();
                            break;

                    }
                    break;
                default:
                    ret = new NullTsapiReturn();
                    break;
            }

            CbTaskNew.Set(data.invokeID, ret);
        }


        protected void Cstaeventreport(CstaEventReport data, ATTEvent_t pd, eventTypeCSTA eventType)
        {
            switch (pd.eventType)
            {
                case TypeATTEvent.ATTQueryAgentLoginResp_t_PDU:
                    var crid = pd.queryAgentLoginResp.privEventCrossRefID;
                    if (pd.queryAgentLoginResp.list.count != 0)
                    {
                        var list =
                            pd.queryAgentLoginResp.list.list.Take(pd.queryAgentLoginResp.list.count)
                                .Select(_ => _.device)
                                .ToList();
                        ReportArray.AddOrUpdate(crid,
                            list,
                            (u, o) =>
                            {
                                var l = o as List<String>;
                                if (l != null)
                                    l.AddRange(list);
                                return (object)l;
                            });
                        CbTaskForToPartNew.UpdateTimeout(crid);

                    }
                    else
                    {
                        object obj;
                        var flag = ReportArray.TryRemove(crid, out obj);
                        CbTaskForToPartNew.Set(crid, flag ? obj : new List<String>());

                    }
                    break;



            }
        }


        protected void Cstarequest(CstaRequestEvent data, ATTEvent_t pd, eventTypeCSTA eventType)
        {

        }

        protected void Cstaunsolicited(CstaUnsolicitedEvent data, ATTEvent_t pd, eventTypeCSTA eventType)
        {

            MonitorEventCollection evnt;
            if (Monitors.TryGetValue((int)data.monitorCrossRefId, out evnt))
            {
                if (eventType == eventTypeCSTA.CSTA_DELIVERED)
                {

                }
                evnt.Invoke(data, eventType, pd);
                if (eventType == eventTypeCSTA.CSTA_MONITOR_STOP || eventType == eventTypeCSTA.CSTA_MONITOR_ENDED)
                {
                    Monitors.TryRemove((int)data.monitorCrossRefId, out evnt);
                    evnt.Dispose();
                }
            }

        }
        protected virtual void Dispose(bool disposing)
        {
            Log.DebugFormat("Wait command: {0}", CbTaskNew.CurrentCommand());
            Log.DebugFormat("{0} : Destructor", LinkName);
            if (Disposed) return;
            if (disposing)
            {
                Marshal.FreeHGlobal(_ptrCsta);
                Marshal.FreeHGlobal(_ptrPd);
                Marshal.FreeHGlobal(_ptrAtt);

            }
            _acsHandle = 0;
            _closed.Cancel(false);
            _closed.Dispose();
            foreach (var variable in CbTaskNew)
            {
                variable.Value.Set(null);
            }
            CbTaskNew.Clear();

            foreach (var variable in Monitors)
            {
                variable.Value.Dispose();
            }
            Monitors.Clear();

            foreach (var variable in Agents)
            {
                variable.Value.Dispose();
            }
            Agents.Clear();
            CbEvent = null;
            _callBackAnkor = null;
        }
    }
}
