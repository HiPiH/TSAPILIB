﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace TSAPILIB2
{
    public class Tsapi : Event
    {
        public Tsapi()
        {
            Init();
        }

        public Tsapi(String server, String login, String password, String appName, String apiVersion,
            String privateVersion) :
                base(server, login, password, appName, apiVersion, privateVersion)
        {
            Init();
        }

        public event DelegateConnected OnConnnected;
        public event DelegateClosed OnClosed;
        public event DelegateUniversalFailureSys OnUniversalFailureSys;

        protected void Init()
        {
            OnClosedEvent += TSAPI_OnClosedEvent;
            OnConnnectedEvent += TSAPI_OnConnnectedEvent;
            OnUniversalFailureSysEvent += TSAPI_OnUniversalFailureSysEvent;
        }


        private void TSAPI_OnUniversalFailureSysEvent(object sender, UniversalFailureSys arg)
        {
            if (OnUniversalFailureSys != null) OnUniversalFailureSys(this, arg);
        }

        private void TSAPI_OnConnnectedEvent(object sender, EventArgs args)
        {
            if (OnConnnected != null) OnConnnected(this, null);
        }

        private void TSAPI_OnClosedEvent(object sender, EventArgs args)
        {
            if (OnClosed != null) OnClosed(this, null);
        }


        public Task<QueryAcdSplitEventReturn> GetQueryAcdSplit(string deviceId)
        {
            return CreateTask<QueryAcdSplitEventReturn>((u, t) =>
                NativeMethods.attQueryAcdSplit(ref t, deviceId) |
                NativeMethods.cstaEscapeService(AcsHandle, u, ref t)
                , String.Format("GetQueryAcdSplit('{0}')", deviceId));

            /*AnalizeError(invokeID, NativeMethods.attQueryAcdSplit(ref pd, deviceID));
                 AnalizeError(invokeID, NativeMethods.cstaEscapeService(ACSHandle, invokeID, ref pd));*/

            /*var task = new TaskCompletionSource<QueryAcdSplitEventReturn>();
                    var item = CallBackList.Add(invokeID);
                    AnalizeError(invokeID, NativeMethods.attQueryAcdSplit(ref pd, deviceID));
                    AnalizeError(invokeID, NativeMethods.cstaEscapeService(ACSHandle, invokeID, ref pd));
                    return item.Wait<QueryAcdSplitEventReturn>();*/
        }


        public Task<ApiCapsEventReturn> GetApiCaps()
        {
            /*if (StatusConnection != StatusConection.Open) return default(APICapsEventReturn);
            var invokeID = InvokeID;
            var item = CallBackList.Add(invokeID);
            AnalizeError(invokeID,NativeMethods.cstaGetAPICaps(ACSHandle, invokeID));
            return item.Wait <APICapsEventReturn>();*/
            return CreateTask<ApiCapsEventReturn>((u, t) =>
                NativeMethods.cstaGetAPICaps(AcsHandle, u),
                "GetAPICaps"
                );
        }

        public Task<QueryDeviceInfoReturn> GetQueryDeviceInfo(String device)
        {
            /*if (StatusConnection != StatusConection.Open) return default(QueryDeviceInfoReturn);
            var invokeID = InvokeID;
            var pd = new PrivateData_t();
            var item = CallBackList.Add(invokeID);
            AnalizeError(invokeID, NativeMethods.cstaQueryDeviceInfo(ACSHandle, invokeID, device, ref pd));
            return item.Wait < QueryDeviceInfoReturn>();*/
            return CreateTask<QueryDeviceInfoReturn>((invokeId, pd) =>
                NativeMethods.cstaQueryDeviceInfo(AcsHandle, invokeId, device, ref pd), String.Format("GetQueryDeviceInfo('{0}')", device)
                );
        }

        public Task<GetDeviceListEventReturn> GetDeviceList(int index, CSTALevel_t level)
        {
            /*if (StatusConnection != StatusConection.Open) return default(GetDeviceListEventReturn);
            var invokeID = InvokeID;
            var item = CallBackList.Add(invokeID);
            AnalizeError(invokeID, NativeMethods.cstaGetDeviceList(ACSHandle, invokeID, index, level));
            return item.Wait<GetDeviceListEventReturn>(); */
            return CreateTask<GetDeviceListEventReturn>((invokeId, pd) =>
                NativeMethods.cstaGetDeviceList(AcsHandle, invokeId, index, level)
                , String.Format("GetDeviceList('{0}','{1}')", index, level)
                );
        }


        public Task<QueryStationStatusEventReturn> GetQueryStationStatus(string deviceId)
        {
            /* if (StatusConnection != StatusConection.Open) return default(QueryStationStatusEventReturn);
            var invokeID = InvokeID;
            var pd = new PrivateData_t();
            var item = CallBackList.Add(invokeID);
            AnalizeError(invokeID, NativeMethods.attQueryStationStatus(ref pd, deviceID));
            AnalizeError(invokeID, NativeMethods.cstaEscapeService(ACSHandle, invokeID, ref pd));
            return item.Wait<QueryStationStatusEventReturn>();*/

            return CreateTask<QueryStationStatusEventReturn>((invokeId, pd) =>
                NativeMethods.attQueryStationStatus(ref pd, deviceId) |
                NativeMethods.cstaEscapeService(AcsHandle, invokeId, ref pd)
                , String.Format("GetQueryStationStatus('{0}')", deviceId)
                );
        }

        public Task<QueryUcidEventReturn> GetQueryUcid(ConnectionID_t call)
        {
            /*if (StatusConnection != StatusConection.Open) return default(QueryUCIDEventReturn);
            var invokeID = InvokeID;
            var pd = new PrivateData_t();
            var item = CallBackList.Add(invokeID);
            AnalizeError(invokeID, NativeMethods.attQueryUCID(ref pd, ref call));
            AnalizeError(invokeID, NativeMethods.cstaEscapeService(ACSHandle, invokeID, ref pd));
            return item.Wait < QueryUCIDEventReturn>();*/

            return CreateTask<QueryUcidEventReturn>((invokeId, pd) =>
                NativeMethods.attQueryUCID(ref pd, ref call) |
                NativeMethods.cstaEscapeService(AcsHandle, invokeId, ref pd)
                , String.Format("GetQueryUCID('{0}')", call)
                );
        }

        public Task<NullTsapiReturn> SetSendDtmfTone(ConnectionID_t call, string tone, int pauseDuartion)
        {
            /*Thread.Sleep(pauseDuartion * 1000);
            if (StatusConnection != StatusConection.Open) return;
            var list = new ATTV4ConnIDList_t();
            var invokeID = InvokeID;
            var pd = new PrivateData_t();
            var item = CallBackList.Add(invokeID);            
            AnalizeError(invokeID, NativeMethods.attSendDTMFTone(ref pd, ref call, ref list, tone, 0, 0));
            AnalizeError(invokeID, NativeMethods.cstaEscapeService(ACSHandle, invokeID, ref pd));
            item.Wait();
            Thread.Sleep(tone.Length * 500);*/

            var list = new ATTV4ConnIDList_t();
            return CreateTask<NullTsapiReturn>((invokeId, pd) =>
                NativeMethods.attSendDTMFTone(ref pd, ref call, ref list, tone, 0, 0) |
                NativeMethods.cstaEscapeService(AcsHandle, invokeId, ref pd)
                , String.Format("SetSendDTMFTone('{0}','{1}','{2}')", call, tone, pauseDuartion)
                );
        }

        public Task<MakeCallEventReturn> SetMakeCall(string callingDevice, string calledDevice, string destroute,
            bool priorityCall, ATTV5UserToUserInfo_t info)
        {
            /*if (StatusConnection != StatusConection.Open) return default(MakeCallEventReturn);
            var invokeID = InvokeID;
            var pd = new PrivateData_t();
            var item = CallBackList.Add(invokeID);
            AnalizeError(invokeID, NativeMethods.attMakeCall(ref pd, destroute, priorityCall, ref info));
            AnalizeError(invokeID, NativeMethods.cstaMakeCall(ACSHandle, invokeID, callingDevice, calledDevice, ref pd));
            return item.Wait <MakeCallEventReturn>();*/
            return CreateTask<MakeCallEventReturn>((invokeId, pd) =>
                NativeMethods.attMakeCall(ref pd, destroute, priorityCall, ref info) |
                NativeMethods.cstaMakeCall(AcsHandle, invokeId, callingDevice, calledDevice, ref pd)
                ,
                String.Format("SetMakeCall('{0}','{1}','{2}','{3}','{4}')", callingDevice, calledDevice, destroute,
                    priorityCall, info)
                );
        }

        public Task<NullTsapiReturn> SetAlternateCall(ConnectionID_t activeCall, ConnectionID_t otherCall)
        {
            /* if (StatusConnection != StatusConection.Open) return;
            var invokeID = InvokeID;
            var pd = new PrivateData_t();
            var item = CallBackList.Add(invokeID);
            AnalizeError(invokeID, NativeMethods.cstaAlternateCall(ACSHandle, invokeID, ref activeCall, ref otherCall, ref pd));
            item.Wait();*/
            return CreateTask<NullTsapiReturn>((invokeId, pd) =>
                NativeMethods.cstaAlternateCall(AcsHandle, invokeId, ref activeCall, ref otherCall, ref pd)
                , String.Format("SetAlternateCall('{0}','{1}')", activeCall, otherCall)
                );
        }

        public Task<NullTsapiReturn> SetAnswerCall(ConnectionID_t allertingCall)
        {
            /*if (StatusConnection != StatusConection.Open) return;
            var invokeID = InvokeID;
            var pd = new PrivateData_t();
            var item = CallBackList.Add(invokeID);
            AnalizeError(invokeID, NativeMethods.cstaAnswerCall(ACSHandle, invokeID, ref allertingCall, ref pd));
            item.Wait();*/

            return CreateTask<NullTsapiReturn>((invokeId, pd) =>
                NativeMethods.cstaAnswerCall(AcsHandle, invokeId, ref allertingCall, ref pd)
                , String.Format("SetAnswerCall('{0}')", allertingCall)
                );
        }

        public Task<NullTsapiReturn> SetCallCompletion(ConnectionID_t call, Feature_t feature)
        {
            /*if (StatusConnection != StatusConection.Open) return;
            var invokeID = InvokeID;
            var pd = new PrivateData_t();
            var item = CallBackList.Add(invokeID);
            AnalizeError(invokeID, NativeMethods.cstaCallCompletion(ACSHandle, invokeID, feature, ref call, ref pd));
            item.Wait();    */
            return CreateTask<NullTsapiReturn>((invokeId, pd) =>
                NativeMethods.cstaCallCompletion(AcsHandle, invokeId, feature, ref call, ref pd)
                , String.Format("SetCallCompletion('{0}','{1}')", call, feature)
                );
        }

        public Task<NullTsapiReturn> SetClearCall(ConnectionID_t call)
        {
            /* if (StatusConnection != StatusConection.Open) return;
            var invokeID = InvokeID;
            var pd = new PrivateData_t();
            var item = CallBackList.Add(invokeID);
            AnalizeError(invokeID, NativeMethods.cstaClearCall(ACSHandle, invokeID, ref call, ref pd));
            item.Wait();*/
            return CreateTask<NullTsapiReturn>((invokeId, pd) =>
                NativeMethods.cstaClearCall(AcsHandle, invokeId, ref call, ref pd)
                , String.Format("SetClearCall('{0}')", call)
                );
        }

        public Task<NullTsapiReturn> SetClearConnection(ConnectionID_t call, ATTDropResource_t resourse,
            ATTV5UserToUserInfo_t info)
        {
            /*if (StatusConnection != StatusConection.Open) return;
            var invokeID = InvokeID;
            var pd = new PrivateData_t();
            var item = CallBackList.Add(invokeID);
            AnalizeError(invokeID, NativeMethods.attClearConnection(ref pd, resourse, ref info));
            AnalizeError(invokeID, NativeMethods.cstaClearConnection(ACSHandle, invokeID, ref call, ref pd));
            item.Wait();*/
            return CreateTask<NullTsapiReturn>((invokeId, pd) =>
                NativeMethods.attClearConnection(ref pd, resourse, ref info) |
                NativeMethods.cstaClearConnection(AcsHandle, invokeId, ref call, ref pd)
                , String.Format("SetClearConnection('{0}','{1}','{2}')", call, resourse, info)
                );
        }

        public Task<ConferenceCallEventReturn> SetConferenceCall(ConnectionID_t activeCall, ConnectionID_t otherCall)
        {
            /*if (StatusConnection != StatusConection.Open) return default(ConferenceCallEventReturn);
            var invokeID = InvokeID;
            var pd = new PrivateData_t();
            var item = CallBackList.Add(invokeID);
            AnalizeError(invokeID, NativeMethods.cstaConferenceCall(ACSHandle, invokeID, ref otherCall, ref activeCall, ref pd));
            return item.Wait < ConferenceCallEventReturn>();*/

            return CreateTask<ConferenceCallEventReturn>((invokeId, pd) =>
                NativeMethods.cstaConferenceCall(AcsHandle, invokeId, ref otherCall, ref activeCall, ref pd)
                , String.Format("SetConferenceCall('{0}','{1}')", activeCall, otherCall)
                );
        }

        public Task<ConsultationCallEventReturn> SetConsultationCall(ConnectionID_t activeCall, string calledDevice,
            string destRoute, bool priorityCalling, ATTV5UserToUserInfo_t info)
        {
            /*  if (StatusConnection != StatusConection.Open) return default(ConsultationCallEventReturn);
            var invokeID = InvokeID;
            var pd = new PrivateData_t();
            var item = CallBackList.Add(invokeID);
            AnalizeError(invokeID, NativeMethods.attConsultationCall(ref pd, destRoute, priorityCalling, ref info));
            AnalizeError(invokeID, NativeMethods.cstaConsultationCall(ACSHandle, invokeID, ref activeCall, calledDevice, ref pd));
            return item.Wait < ConsultationCallEventReturn>();*/
            return CreateTask<ConsultationCallEventReturn>((invokeId, pd) =>
                NativeMethods.attConsultationCall(ref pd, destRoute, priorityCalling, ref info) |
                NativeMethods.cstaConsultationCall(AcsHandle, invokeId, ref activeCall, calledDevice, ref pd),
                String.Format("SetConsultationCall('{0}','{1}','{2}','{3}','{4}')", activeCall, calledDevice, destRoute,
                    priorityCalling, info)
                );
        }

        public Task<NullTsapiReturn> SetDeflectCall(ConnectionID_t deflectCall, string calledDevice)
        {
            /* if (StatusConnection != StatusConection.Open) return;
            var invokeID = InvokeID;
            var pd = new PrivateData_t();
            var item = CallBackList.Add(invokeID);
            AnalizeError(invokeID, NativeMethods.cstaDeflectCall(ACSHandle, invokeID, ref deflectCall, calledDevice, ref pd));
            item.Wait();*/
            return CreateTask<NullTsapiReturn>((invokeId, pd) =>
                NativeMethods.cstaDeflectCall(AcsHandle, invokeId, ref deflectCall, calledDevice, ref pd)
                , String.Format("SetDeflectCall('{0}','{1}')", deflectCall, calledDevice)
                );
        }

        public Task<NullTsapiReturn> SetGroupPickupCall(ConnectionID_t deflectCall, string pickupDevice)
        {
            /* if (StatusConnection != StatusConection.Open) return;
            var invokeID = InvokeID;
            var pd = new PrivateData_t();
            var item = CallBackList.Add(invokeID);
            AnalizeError(invokeID, NativeMethods.cstaGroupPickupCall(ACSHandle, invokeID, ref deflectCall, pickupDevice, ref pd));
            item.Wait();*/
            return CreateTask<NullTsapiReturn>((invokeId, pd) =>
                NativeMethods.cstaGroupPickupCall(AcsHandle, invokeId, ref deflectCall, pickupDevice, ref pd)
                , String.Format("SetGroupPickupCall('{0}','{1}')", deflectCall, pickupDevice)
                );
        }

        public Task<NullTsapiReturn> SetHoldCall(ConnectionID_t activeCall)
        {
            /*if (StatusConnection != StatusConection.Open) return;
            var invokeID = InvokeID;
            var pd = new PrivateData_t();
            var item = CallBackList.Add(invokeID);
            AnalizeError(invokeID, NativeMethods.cstaHoldCall(ACSHandle, invokeID, ref activeCall, false, ref pd));
            item.Wait();*/
            return CreateTask<NullTsapiReturn>((invokeId, pd) =>
                NativeMethods.cstaHoldCall(AcsHandle, invokeId, ref activeCall, false, ref pd)
                , String.Format("SetHoldCall('{0}')", activeCall)
                );
        }

        public Task<MakePredictiveCallEventReturn> SetMakePredictiveCall(string callingDevice, string calledDevice,
            AllocationState_t allocationState, string destRoute, bool priorityCalling, short maxRing,
            ATTAnswerTreat_t answerTreat, ATTV5UserToUserInfo_t info)
        {
            /*if (StatusConnection != StatusConection.Open) return default(MakePredictiveCallEventReturn);
            var invokeID = InvokeID;
            var pd = new PrivateData_t();
            var item = CallBackList.Add(invokeID);
            AnalizeError(invokeID, NativeMethods.attMakePredictiveCall(ref pd, priorityCalling, maxRing, answerTreat, destRoute, ref info));            
            AnalizeError(invokeID, NativeMethods.cstaMakePredictiveCall(ACSHandle, invokeID, callingDevice, calledDevice, allocationState, ref pd));
            return item.Wait < MakePredictiveCallEventReturn>();*/

            return CreateTask<MakePredictiveCallEventReturn>((invokeId, pd) =>
                NativeMethods.attMakePredictiveCall(ref pd, priorityCalling, maxRing, answerTreat, destRoute, ref info) |
                NativeMethods.cstaMakePredictiveCall(AcsHandle, invokeId, callingDevice, calledDevice, allocationState,
                    ref pd)
                ,
                String.Format("SetMakePredictiveCall('{0}','{1}','{2}','{3}','{4}','{5}','{6}','{7}')", callingDevice,
                    calledDevice, allocationState, destRoute,
                    priorityCalling, maxRing, answerTreat, info)
                );
        }

        public Task<NullTsapiReturn> SetPickupCall(ConnectionID_t deflectCall, string calledDevice)
        {
            /* if (StatusConnection != StatusConection.Open) return;
            var invokeID = InvokeID;
            var pd = new PrivateData_t();
            var item = CallBackList.Add(invokeID);
            AnalizeError(invokeID, NativeMethods.cstaPickupCall(ACSHandle, invokeID, ref deflectCall, calledDevice, ref pd));
            item.Wait();*/
            return CreateTask<NullTsapiReturn>((invokeId, pd) =>
                NativeMethods.cstaPickupCall(AcsHandle, invokeId, ref deflectCall, calledDevice, ref pd)
                , String.Format("SetPickupCall('{0}','{1}')", deflectCall, calledDevice)
                );
        }

        public Task<NullTsapiReturn> SetReconnectCall(ConnectionID_t activeCall, ConnectionID_t heldCall,
            ATTDropResource_t resource, ATTV5UserToUserInfo_t info)
        {
            /*if (StatusConnection != StatusConection.Open) return;
            var invokeID = InvokeID;
            var pd = new PrivateData_t();
            var item = CallBackList.Add(invokeID);
            AnalizeError(invokeID, NativeMethods.attReconnectCall(ref pd, resource, ref info));            
            AnalizeError(invokeID, NativeMethods.cstaReconnectCall(ACSHandle, invokeID, ref activeCall, ref heldCall, ref pd));
            item.Wait(); */

            return CreateTask<NullTsapiReturn>((invokeId, pd) =>
                NativeMethods.attReconnectCall(ref pd, resource, ref info) |
                NativeMethods.cstaReconnectCall(AcsHandle, invokeId, ref activeCall, ref heldCall, ref pd)
                , String.Format("SetReconnectCall('{0}','{1}','{2}','{3}')", activeCall, heldCall, resource, info)
                );
        }

        public Task<NullTsapiReturn> SetRetrieveCall(ConnectionID_t heldCall)
        {
            /*if (StatusConnection != StatusConection.Open) return;
            var invokeID = InvokeID;
            var pd = new PrivateData_t();
            var item = CallBackList.Add(invokeID);
            AnalizeError(invokeID, NativeMethods.cstaRetrieveCall(ACSHandle, invokeID, ref heldCall, ref pd));
            item.Wait();*/
            return CreateTask<NullTsapiReturn>((invokeId, pd) =>
                NativeMethods.cstaRetrieveCall(AcsHandle, invokeId, ref heldCall, ref pd)
                , String.Format("SetRetrieveCall('{0}')", heldCall)
                );
        }

        public Task<TransferCallEventReturn> SetTransferCall(ConnectionID_t activeCall, ConnectionID_t heldCall)
        {
            return CreateTask<TransferCallEventReturn>((invokeId, pd) =>
                NativeMethods.cstaTransferCall(AcsHandle, invokeId, ref activeCall, ref heldCall, ref pd)
                , String.Format("SetTransferCall('{0}','{1}')", activeCall, heldCall)
                );
        }

        public Task<NullTsapiReturn> SetSetMsgWaitingInd(String deviceId, bool messages)
        {
            /*if (StatusConnection != StatusConection.Open) return;
            var invokeID = InvokeID;
            var pd = new PrivateData_t();
            var item = CallBackList.Add(invokeID);
            AnalizeError(invokeID, NativeMethods.cstaSetMsgWaitingInd(ACSHandle, invokeID, deviceID, messages, ref pd));
            item.Wait();*/
            return CreateTask<NullTsapiReturn>((invokeId, pd) =>
                NativeMethods.cstaSetMsgWaitingInd(AcsHandle, invokeId, deviceId, messages, ref pd)
                , String.Format("SetSetMsgWaitingInd('{0}','{1}')", deviceId, messages)
                );
        }

        public Task<NullTsapiReturn> SetAgentState(String deviceId, String agentId, String agentGroup, String lpassword,
            AgentMode_t mode,
            ATTWorkMode_t wmode, int reasonCode)
        {
            /* if (StatusConnection != StatusConection.Open) return;
            var invokeID = InvokeID;
            var pd = new PrivateData_t();
            var item = CallBackList.Add(invokeID);
            AnalizeError(invokeID, NativeMethods.attSetAgentStateExt(ref pd, wmode, reasonCode));           
            AnalizeError(invokeID, NativeMethods.cstaSetAgentState(ACSHandle, invokeID, deviceID, mode, agentID, agentGroup, lpassword, ref pd));
            item.Wait() ;*/

            return CreateTask<NullTsapiReturn>((invokeId, pd) =>
                NativeMethods.attSetAgentStateExt(ref pd, wmode, reasonCode) |
                NativeMethods.cstaSetAgentState(AcsHandle, invokeId, deviceId, mode, agentId, agentGroup, lpassword,
                    ref pd)
                , String.Format("SetAgentState('{0}','{1}','{2}','{3}','{4}','{5}','{6}')",
                    deviceId, agentId, agentGroup, lpassword, mode, wmode, reasonCode)
                );
        }

        public Task<QueryMsgWaitingEventReturn> GetQueryMsgWaitingInd(String deviceId)
        {
            /*if (StatusConnection != StatusConection.Open) return default(QueryMsgWaitingEventReturn);
            var invokeID = InvokeID;
            var pd = new PrivateData_t();
            var item = CallBackList.Add(invokeID);
            AnalizeError(invokeID, NativeMethods.cstaQueryMsgWaitingInd(ACSHandle, invokeID, deviceID, ref pd));
            return item.Wait < QueryMsgWaitingEventReturn>();*/

            return CreateTask<QueryMsgWaitingEventReturn>((invokeId, pd) =>
                NativeMethods.cstaQueryMsgWaitingInd(AcsHandle, invokeId, deviceId, ref pd)
                , String.Format("GetQueryMsgWaitingInd('{0}')", deviceId)
                );
        }

        public Task<QueryAgentStateEventReturn> GetQueryAgentState(String deviceId)
        {
            /*if (StatusConnection != StatusConection.Open) return default(QueryAgentStateEventReturn);
            var invokeID = InvokeID;
            var pd = new PrivateData_t();
            var item = CallBackList.Add(invokeID);
            AnalizeError(invokeID, NativeMethods.cstaQueryAgentState(ACSHandle, invokeID, deviceID, ref pd));

            var ret = item.Wait<QueryAgentStateEventReturn>();
            MonitorEventAgentCollection evnt;
            if (Agents.TryGetValue(deviceID, out evnt))
            {
                evnt.Invoke(ret.CSTA, ret.Att);
            }
            return ret;*/


            return CreateTask<QueryAgentStateEventReturn>((invokeId, pd) =>
                NativeMethods.cstaQueryAgentState(AcsHandle, invokeId, deviceId, ref pd)
                , String.Format("GetQueryAgentState('{0}')", deviceId)
                ).ContinueWith(task =>
                {
                    MonitorEventAgentCollection evnt;
                    if (Agents.TryGetValue(deviceId, out evnt))
                    {
                        evnt.Invoke(task.Result.Csta, task.Result.Att);
                    }
                    return task.Result;
                });
        }

        public Task<QueryLastNumberEventReturn> GetQueryLastNumber(String deviceId)
        {
            /*if (StatusConnection != StatusConection.Open) return default(QueryLastNumberEventReturn);
            var invokeID = InvokeID;
            var pd = new PrivateData_t();
            var item = CallBackList.Add(invokeID);
            AnalizeError(invokeID, NativeMethods.cstaQueryLastNumber(ACSHandle, invokeID, deviceID, ref pd));
            return item.Wait < QueryLastNumberEventReturn>(); */

            return CreateTask<QueryLastNumberEventReturn>((invokeId, pd) =>
                NativeMethods.cstaQueryLastNumber(AcsHandle, invokeId, deviceId, ref pd)
                , String.Format("GetQueryLastNumber('{0}')", deviceId)
                );
        }


        public Task<NullTsapiReturn> SetMonitorStop(uint monitorCrossId)
        {
            /* if (StatusConnection != StatusConection.Open) return;
            var invokeID = InvokeID;
            var pd = new PrivateData_t();
            var item = CallBackList.Add(invokeID);
            AnalizeError(invokeID, NativeMethods.cstaMonitorStop(ACSHandle, invokeID, monitorCrossId, ref pd));
            item.Wait() ;
            MonitorEventCollection evnt;
            if (!Monitors.TryGetValue((int) monitorCrossId, out evnt)) return;
            evnt.MonitorEndedInvoke(new CSTAMonitorEndedEvent_t());
            Monitors.TryRemove((int)monitorCrossId, out evnt);
            evnt.Dispose();*/

            return CreateTask<NullTsapiReturn>((invokeId, pd) =>
                NativeMethods.cstaMonitorStop(AcsHandle, invokeId, monitorCrossId, ref pd)
                , String.Format("SetMonitorStop('{0}')", monitorCrossId)
                ).ContinueWith(task =>
                {
                    MonitorEventCollection evnt;
                    if (!Monitors.TryGetValue((int) monitorCrossId, out evnt)) return task.Result;
                    evnt.MonitorEndedInvoke(new CSTAMonitorEndedEvent_t());
                    Monitors.TryRemove((int) monitorCrossId, out evnt);
                    evnt.Dispose();
                    return task.Result;
                });
        }

        public Task<ChangeMonitorFilterEventReturn> SetChangeMonitorFilter(uint monitorCrossId,
            CSTAMonitorFilter_t filter)
        {
            /*if (StatusConnection != StatusConection.Open) return default(ChangeMonitorFilterEventReturn);
            var invokeID = InvokeID;
            var pd = new PrivateData_t();
            var item = CallBackList.Add(invokeID);
            AnalizeError(invokeID, NativeMethods.cstaChangeMonitorFilter(ACSHandle, invokeID, monitorCrossId, ref filter, ref pd));
            return item.Wait < ChangeMonitorFilterEventReturn>(); */
            return CreateTask<ChangeMonitorFilterEventReturn>((invokeId, pd) =>
                NativeMethods.cstaChangeMonitorFilter(AcsHandle, invokeId, monitorCrossId, ref filter, ref pd)
                , String.Format("SetChangeMonitorFilter('{0}','{1}')", monitorCrossId, filter)
                );
        }

        public Task<SnapshotCallEventReturn> SetSnapshotCallReq(ConnectionID_t call)
        {
            /*if (StatusConnection != StatusConection.Open) return default(SnapshotCallEventReturn);
            var invokeID = InvokeID;
            var pd = new PrivateData_t();
            var item = CallBackList.Add(invokeID);
            AnalizeError(invokeID, NativeMethods.cstaSnapshotCallReq(ACSHandle, invokeID, ref call, ref pd));
            return item.Wait < SnapshotCallEventReturn>();*/
            return CreateTask<SnapshotCallEventReturn>((invokeId, pd) =>
                NativeMethods.cstaSnapshotCallReq(AcsHandle, invokeId, ref call, ref pd)
                , String.Format("SetSnapshotCallReq('{0}')", call)
                );
        }

        public Task<SnapshotDeviceEventReturn> SetSnapshotDeviceReq(string deviceId)
        {
            /*if (StatusConnection != StatusConection.Open) return default(SnapshotDeviceEventReturn);
            var invokeID = InvokeID;
            var pd = new PrivateData_t();
            var item = CallBackList.Add(invokeID);
            AnalizeError(invokeID, NativeMethods.cstaSnapshotDeviceReq(ACSHandle, invokeID, deviceID, ref pd));
            return item.Wait < SnapshotDeviceEventReturn>();*/
            return CreateTask<SnapshotDeviceEventReturn>((invokeId, pd) =>
                NativeMethods.cstaSnapshotDeviceReq(AcsHandle, invokeId, deviceId, ref pd)
                , String.Format("SetSnapshotDeviceReq('{0}')", deviceId)
                );
        }

        public Task<List<String>> GetQueryAgentLogin(string deviceId)
        {
            return CreateTask<List<String>>((invokeId, pd) =>
                NativeMethods.attQueryAgentLogin(ref pd, deviceId) |
                NativeMethods.cstaEscapeService(AcsHandle, invokeId, ref pd)
                , String.Format("GetQueryAgentLogin('{0}')", deviceId)
                );
        }


        public Task<QueryCallMonitorEventReturn> SetQueryCallMonitor(string deviceId)
        {
            /*if (StatusConnection != StatusConection.Open) return default(QueryCallMonitorEventReturn);
            var invokeID = InvokeID;
            var item = CallBackList.Add(invokeID);
            AnalizeError(invokeID, NativeMethods.cstaQueryCallMonitor(ACSHandle, invokeID));
            return item.Wait < QueryCallMonitorEventReturn>();*/
            return CreateTask<QueryCallMonitorEventReturn>((invokeId, pd) =>
                NativeMethods.cstaQueryCallMonitor(AcsHandle, invokeId)
                , String.Format("SetQueryCallMonitor('{0}')", deviceId)
                );
        }

        public Task<MonitorEventCollection> SetMonitorDevice(String deviceId, CSTAMonitorFilter_t filter)
        {
            /* if (StatusConnection != StatusConection.Open) return null;
            var invokeID = InvokeID;
            var pd = new PrivateData_t();
            var item = CallBackList.Add(invokeID);
            AnalizeError(invokeID, NativeMethods.cstaMonitorDevice(ACSHandle, invokeID, deviceID, ref filter, ref pd));
            var rtet = item.Wait < SetupMonitorEventReturn>();
            var monitoEvent = new MonitorEventCollection(rtet.CSTA.monitorCrossRefID, deviceID);
            Monitors.TryAdd((int)rtet.CSTA.monitorCrossRefID, monitoEvent);
            return monitoEvent;*/
            return CreateTask<SetupMonitorEventReturn>((invokeId, pd) =>
                NativeMethods.cstaMonitorDevice(AcsHandle, invokeId, deviceId, ref filter, ref pd)
                , String.Format("SetMonitorDevice('{0}','{1}')", deviceId, filter)
                ).ContinueWith(task =>
                {
                    var monitoEvent = new MonitorEventCollection(task.Result.Csta.monitorCrossRefID, deviceId);
                    Monitors.TryAdd((int) task.Result.Csta.monitorCrossRefID, monitoEvent);
                    return monitoEvent;
                });
        }

        public Task<MonitorEventCollection> SetMonitorCall(ConnectionID_t call, CSTAMonitorFilter_t filter)
        {
            /*  if (StatusConnection != StatusConection.Open) return null;
            var invokeID = InvokeID;
            var pd = new PrivateData_t();
            var item = CallBackList.Add(invokeID);
            AnalizeError(invokeID, NativeMethods.cstaMonitorCall(ACSHandle, invokeID, ref call, ref filter, ref pd));
            var rtet = item.Wait < SetupMonitorEventReturn>();
            var monitoEvent = new MonitorEventCollection(rtet.CSTA.monitorCrossRefID, call);
            Monitors.TryAdd((int)rtet.CSTA.monitorCrossRefID, monitoEvent);
            return monitoEvent;*/
            return CreateTask<SetupMonitorEventReturn>((invokeId, pd) =>
                NativeMethods.cstaMonitorCall(AcsHandle, invokeId, ref call, ref filter, ref pd)
                , String.Format("SetMonitorCall('{0}','{1}')", call, filter)
                ).ContinueWith(task =>
                {
                    var monitoEvent = new MonitorEventCollection(task.Result.Csta.monitorCrossRefID, call);
                    Monitors.TryAdd((int) task.Result.Csta.monitorCrossRefID, monitoEvent);
                    return monitoEvent;
                });
        }

        public Task<MonitorEventCollection> SetMonitorCallsViaDevice(String deviceId, CSTAMonitorFilter_t filter)
        {
            /*if (StatusConnection != StatusConection.Open) return null;
            var invokeID = InvokeID;
            var pd = new PrivateData_t();
            var item = CallBackList.Add(invokeID);
            AnalizeError(invokeID, NativeMethods.cstaMonitorCallsViaDevice(ACSHandle, invokeID, deviceID, ref filter, ref pd));
            var rtet = item.Wait < SetupMonitorEventReturn>();
            var monitoEvent = new MonitorEventCollection(rtet.CSTA.monitorCrossRefID, deviceID);
            Monitors.TryAdd((int)rtet.CSTA.monitorCrossRefID, monitoEvent);
            return monitoEvent;*/

            return CreateTask<SetupMonitorEventReturn>((invokeId, pd) =>
                NativeMethods.cstaMonitorCallsViaDevice(AcsHandle, invokeId, deviceId, ref filter, ref pd)
                , String.Format("SetMonitorCallsViaDevice('{0}','{1}')", deviceId, filter)
                ).ContinueWith(task =>
                {
                    var monitoEvent = new MonitorEventCollection(task.Result.Csta.monitorCrossRefID, deviceId);
                    Monitors.TryAdd((int) task.Result.Csta.monitorCrossRefID, monitoEvent);
                    return monitoEvent;
                });
        }

        public MonitorEventAgentCollection SetMonitorAgent(String agentId)
        {
            if (StatusConnection != StatusConection.Open) return null;
            GetQueryAgentState(agentId);
            var mon = new MonitorEventAgentCollection(this, agentId);
            if (!Agents.TryAdd(agentId, mon))
                Agents.TryGetValue(agentId, out mon);
            return mon;
        }

        public void SetMonitorAgentStop(String agentId)
        {
            if (StatusConnection != StatusConection.Open) return;
            MonitorEventAgentCollection mon;
            Agents.TryRemove(agentId, out mon);
            mon.Dispose();
        }

        protected override void Dispose(bool disposing)
        {
            if (Disposed) return;
            if (disposing)
            {
                StatusConnection = StatusConection.Close;
            }


            base.Dispose(false);
        }
    }
}